--level task c
--task 16

use level_task_C

UPDATE my_table
SET 
    column1 = column2,
    column2 = column1
WHERE id = 1;  -- Replace 1 with the actual condition or id value.
