USE AdventureWorks2019;
GO

SELECT dbo.FormatDateMMDDYYYY('2006-11-21 23:34:05.920') AS FormattedDate;
GO