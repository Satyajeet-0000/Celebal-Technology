USE AdventureWorks2019;
GO

SELECT *
FROM MyProducts;
GO