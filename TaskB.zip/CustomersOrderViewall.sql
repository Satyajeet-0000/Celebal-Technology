USE AdventureWorks2019; -- Again, ensure you are in the correct database context
GO

SELECT *
FROM vwCustomerOrders;
GO