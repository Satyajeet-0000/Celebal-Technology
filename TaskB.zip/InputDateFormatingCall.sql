USE AdventureWorks2019;
GO

SELECT dbo.FormatDateYYYYMMDD('2025-05-30 14:30:00') AS FormattedDate;
GO